package com.slk.training.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.slk.training.dao.DaoException;
import com.slk.training.dao.impl.ProductDaoJdbcImpl;
import com.slk.training.entity.Product;


@WebServlet("/ProductsByCategoryServlet")
public class ProductsByCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String input=request.getParameter("category");
		PrintWriter out=response.getWriter();
		ProductDaoJdbcImpl pm=new  ProductDaoJdbcImpl();
		
			
			
				List<Product> p;
			try {
				
				p = pm.getProductsByCategory(input);
				request.setAttribute("Product", p);
			} catch (DaoException e) {
				
				e.printStackTrace();
			}
		RequestDispatcher rd =  request.getRequestDispatcher("/WEB-INF/showproducts.jsp");
		rd.forward(request, response);
			
			
			
	
	
			
	}
}
	


