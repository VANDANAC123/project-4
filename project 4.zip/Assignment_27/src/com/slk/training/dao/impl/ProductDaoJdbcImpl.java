package com.slk.training.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.slk.training.dao.DaoException;
import com.slk.training.dao.ProductDao;
import com.slk.training.entity.Product;

public class ProductDaoJdbcImpl implements ProductDao {
	
	private Connection openConnection() throws ClassNotFoundException, SQLException  {
		Class.forName("org.h2.Driver");
		String url = "jdbc:h2:tcp://localhost/~/slk_training_2018_12";
		String user = "sa";
		String password = "";
		return DriverManager.getConnection(url, user, password);
	}
	@Override
	public Product getProductById(int id) throws DaoException {
		

		String sql="select * from product where id=?";
		try (Connection conn = openConnection(); PreparedStatement stmt = conn.prepareStatement(sql);){
			stmt.setInt(1,id);
		
				ResultSet rs= stmt.executeQuery();
	           
			
			while(rs.next()) {
				Product p=new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				return p;
			}
	           }
					 catch (Exception ex) {
					// this is wrong;execution must be propagated to the presentation layer to be
					// done later
					ex.printStackTrace();
				}
		return null;
		
	}
	
	
	@Override
	public List<Product> getAllProducts() throws DaoException {
		List<Product> list=new ArrayList<>();
		String sql="select * from Product";
		
		try(Connection conn =openConnection();
				PreparedStatement stmt=conn.prepareStatement(sql);
				ResultSet rs=stmt.executeQuery();)
		{
			while(rs.next())
			{
				Product r=new Product();
				r.setId(rs.getInt("id"));
				r.setName(rs.getString("name"));
				r.setCategory(rs.getString("category"));
				r.setPrice(rs.getInt("price"));
				list.add(r);
				
			}
			
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;

		
	}
	@Override
	public List<Product> getProductsByCategory(String category) throws DaoException {
	List<Product> list=new ArrayList<>();
		String sql="select * from Product where category =?";
		try (Connection conn = openConnection(); PreparedStatement stmt = conn.prepareStatement(sql);){
			stmt.setString(1,category );
		
				ResultSet rs= stmt.executeQuery();
	           
			
			while(rs.next()) {
				Product p=new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getInt("price"));
				list.add(p);
			}
	           }
					 catch (Exception ex) {
					// this is wrong;execution must be propagated to the presentation layer to be
					// done later
					ex.printStackTrace();
				}
		return list;
		
	}






	


}
