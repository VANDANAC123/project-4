package com.slk.training.dao;

import com.slk.training.dao.impl.ProductDaoJdbcImpl;

public class DaoFactory {
	

		private static final String discriminator = "HASHMAP";

		private DaoFactory() {
		}

		public static ProductDao getProductDao() throws DaoException {
			switch (discriminator.toUpperCase()) {
			case "JDBC":
				  return new ProductDaoJdbcImpl();
				// break;
			case "HASHMAP":
				//return new ContactsDaoHashMapImpl();
			case "CSV":
				// return new ContactsDaoCsvImpl();
				break;
			case "ARRAYLIST":
				// return new ContactsDaoArrayListImpl();
				//break;
			}
			throw new DaoException("No implementation found for discriminator: " + discriminator);
		}
	}


