package com.slk.training.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.slk.training.Admin;
import com.slk.training.ManagerDetails;
import com.slk.training.register;


@WebServlet("/AdminLogInServlet")
public class AdminLogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/login.jsp").forward(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String input;
		Admin a=new Admin();
		
		 input=request.getParameter("admin_name");
		 a.setAdmin_name(input);
		 input=request.getParameter("password");
		 a.setPassword(input);
		
		 
		 
		 ManagerDetails md=new ManagerDetails();
		 

		 md.AddNewAdmin(a);
		 
		 response.sendRedirect("./GetAllBookServlet2");
	}

}