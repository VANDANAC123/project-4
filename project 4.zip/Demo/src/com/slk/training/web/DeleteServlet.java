package com.slk.training.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.slk.training.BookDetails;
import com.slk.training.ManagerDetails;
import com.slk.training.user;
//import com.slk.training.dao.ProductManager;


@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String input=request.getParameter("book_id");
		int book_id=Integer.parseInt(input);
		 ManagerDetails pm=new  ManagerDetails();
		BookDetails p= pm.getbookById(book_id);
		request.setAttribute("BookDetails", p);
		
  request.getRequestDispatcher("/WEB-INF/Book.jsp").forward(request, response);
	}
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String input;
		BookDetails p=new BookDetails();

		user u=new user();
		input=request.getParameter("author");
		u.setAuthor((input));
		input=request.getParameter("book_id");
		p.setBook_id(Integer.parseInt(input));
		input=request.getParameter("book_name");
		p.setBook_name(input);
		input=request.getParameter("author");
				p.setAuthor(input);
						input=request.getParameter("no_of_books");
						p.setNo_of_books(Integer.parseInt(input));
		
		//2. call the model to do the task
			ManagerDetails pm=new ManagerDetails();
			pm.upDatebookdetails(p,u);
						
		//3. store the model data in a scope
		//4.navigate to a view(client side redirection)
			response.sendRedirect("./GetAllServlet");
	}
}