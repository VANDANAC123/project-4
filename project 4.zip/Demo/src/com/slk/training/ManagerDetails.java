package com.slk.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.slk.training.register;

public class ManagerDetails {
	


	private Connection openConnection() throws ClassNotFoundException, SQLException  {
		Class.forName("org.h2.Driver");
		String url = "jdbc:h2:tcp://localhost/~/slk_training_2018_12";
		String user = "sa";
		String password = "";
		return DriverManager.getConnection(url, user, password);
	}
	
	public List<user> getAllUser()  {
	
		List<user> list=new ArrayList<>();
		String sql="select * from user_details";
		
		try(Connection conn =openConnection();
				PreparedStatement stmt=conn.prepareStatement(sql);
				ResultSet rs=stmt.executeQuery();)
		{
			while(rs.next())
			{
				user u=new user();
				u.setUser_name(rs.getString("user_name"));
				u.setUser_id(rs.getInt("user_id"));
				u.setAuthor(rs.getString("author"));
				u.setNo_of_books(rs.getInt("no_of_books"));
				
				list.add(u);
				
			}
			
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}
	
	 public void AddNewUser1(register r) {
	
		 String sql="insert into register values(?,?,?)";
		 try(Connection conn =openConnection();
					PreparedStatement stmt=conn.prepareStatement(sql);
					)
		 {
			 
				stmt.setString(1,r.getUsername());
				stmt.setString(2, r.getPassword());
				stmt.setString(3, r.getEmail());
				stmt.executeUpdate();
				
			
		 }catch (Exception ex) {
				
				ex.printStackTrace();
				
			}
		 }
	 
	 public void AddNewAdmin(Admin a) {
			
		 String sql="insert into admin values(?,?,?)";
		 try(Connection conn =openConnection();
					PreparedStatement stmt=conn.prepareStatement(sql);
					)
		 {
			 
				stmt.setString(1,a.getAdmin_name());
				stmt.setString(2, a.getPassword());
				stmt.setString(3, a.getEmail());
				stmt.executeUpdate();
				
			
		 }catch (Exception ex) {
				
				ex.printStackTrace();
				
			}
	 }

		 
	/* public void validate(String admin_name, String password,String email)
	 {
		 Boolean status=true;
		 String sql="select * from admin where admin_name=?,password=?,email=?";
		 try(Connection conn =openConnection();
					PreparedStatement stmt=conn.prepareStatement(sql);
					)
		 {
			 
				stmt.setString(1,Admin_name());
				stmt.setString(2, Password());
				stmt.setString(3, Email());
				stmt.executeQuery();
				
			
		 }catch (Exception ex) {
				
				ex.printStackTrace();
				
			}*/
public void AddNewUser(user a) {
	
	 String sql="insert into user_details values(?,?,?,?)";
	 try(Connection conn =openConnection();
				PreparedStatement stmt=conn.prepareStatement(sql);
				)
	 {
		 
			stmt.setString(1,a.getUser_name());
			stmt.setInt(2, a.getUser_id());
			stmt.setString(3, a.getAuthor());
			stmt.setInt(4, a.getNo_of_books());
			
			stmt.executeUpdate();
			
		
	 }catch (Exception ex) {
			
			ex.printStackTrace();
			
		}
}

public List<BookDetails> getAllBook() {
	List<BookDetails> list=new ArrayList<>();
	String sql="select * from book_details";
	
	try(Connection conn =openConnection();
			PreparedStatement stmt=conn.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();)
	{
		while(rs.next())
		{
			BookDetails r=new BookDetails();
			r.setBook_id(rs.getInt("book_id"));
			r.setBook_name(rs.getString("book_name"));
			r.setAuthor(rs.getString("author"));
			r.setNo_of_books(rs.getInt("no_of_books"));
			list.add(r);
			
		}
		
	}
	catch (Exception ex) {
		ex.printStackTrace();
	}
	return list;

	
}

public int upDatebookdetails(BookDetails bd,user u) {

	String sql="UPDATE book_details join user_details \r\n" + 
			"ON book_details.author=user_details.author \r\n" + 
			"SET book_details.no_of_books=book_details.?-user_details.?\r\n" + 
			"WHERE book_details.book_id=?";
	try (Connection conn = openConnection(); 
			PreparedStatement stmt = conn.prepareStatement(sql);
			//PreparedStatement stmt1 = conn.prepareStatement(sql1);
		ResultSet rs=stmt.executeQuery();
			)
			//ResultSet rs1=stmt1.executeQuery();
			
			{
		
		stmt.setString(1, bd.getBook_name());
		//stmt.setString(2, bd.getAuthor());
		stmt.setInt(2, u.getNo_of_books());
		stmt.setInt(3, bd.getBook_id());
		
		stmt.executeQuery();
		//stmt1.executeQuery();

	} catch (Exception ex) {
		// this is wrong;execution must be propagated to the presentation layer to be
		// done later
		ex.printStackTrace();
	}
	return 0;
}
	
	
	/*public int count(String author) {
		String sql = "select count(no_of_books) from user_details where author=?";
		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {
			rs.next();
			return rs.getInt(1);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return 0;
	}*/



public BookDetails getbookById(int book_id) {
	

	String sql="select * from book_details  where book_id=?";
	try (Connection conn = openConnection(); PreparedStatement stmt = conn.prepareStatement(sql);){
		stmt.setInt(1, book_id);
	
			ResultSet rs= stmt.executeQuery();
           
		
		while(rs.next()) {
		BookDetails p=new BookDetails();
			p.setBook_id(rs.getInt("book_id"));
			p.setBook_name(rs.getString("book_name"));
			p.setAuthor(rs.getString("author"));
			p.setNo_of_books(rs.getInt("no_of_books"));
			return p;
		}
           }
				 catch (Exception ex) {
				// this is wrong;execution must be propagated to the presentation layer to be
				// done later
				ex.printStackTrace();
			}
	return null;
	
}
}

		 
		 
		 
		 
		 
	 

	
			 
		 

		 
		 
		 
	 


		
		
		
		
	


