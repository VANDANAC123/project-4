package com.slk.training;

public class user {
	
	private  String user_name;
	private int user_id;
	private String author;
	private int no_of_books;
	
	
	
	
	public user() {
		super();
	}

	public user(String user_name, int user_id, String author, int no_of_books) {
		
		this.user_name = user_name;
		this.user_id = user_id;
		this.author = author;
		this.no_of_books = no_of_books;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getNo_of_books() {
		return no_of_books;
	}

	public void setNo_of_books(int no_of_books) {
		this.no_of_books = no_of_books;
	}

	@Override
	public String toString() {
		return "user [user_name=" + user_name + ", user_id=" + user_id + ", author=" + author + ", no_of_books="
				+ no_of_books + "]";
	}

	

}
