package com.slk.training;

public class Admin {
	private String admin_name;
	private String password;
	private String email;
	public Admin() {
		
	}
	public Admin(String admin_name, String password, String email) {
		
		this.admin_name = admin_name;
		this.password = password;
		this.email = email;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Admin [admin_name=" + admin_name + ", password=" + password + ", email=" + email + "]";
	}
	
	
	
	
	
	

}
