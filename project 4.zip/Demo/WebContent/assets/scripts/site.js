function validate() {
	// get the values from the text boxes
	
	var admin_name = $("#admin_name").val();
	var password=$("#password").val();
	var email = $("#email").val();
	var messages = [];
	

	if (!admin_name || admin_name.length < 4 || admin_name.length > 50) {
		messages.push("name is mandatory and must be between 3 to 50 letters");

	}
	if(! password || password.length<4 ||password.length>50){
		messages.push("password is mandatory and must be between 3 to 50 letters");
	}

	if (!email || email.length<4 ||email.length>50) {
		messages.push("email is mandatory and must be>=rs.0");
	}
	

	if (messages.length > 0) {
		// display the errors
		var errors = $("<ul>").addClass("alert alert-danger");
		$("#errors").html(errors);
		messages.forEach(function(msg) {
			errors.append("<li>" + msg + "<li>");

		});

		return false;

	}
	return true;

}

function validate1() {
	// get the values from the text boxes
	
	var user_name = $("#user_name").val();
	var user_id=$("#user_id").val();
	var author = $("#author").val();
	var no_of_books = $("#no_of_books").val();
	
	var messages = [];
	

	if (!user_name || user_name.length < 4 || user_name.length > 50) {
		messages.push("name is mandatory and must be between 3 to 50 letters");

	}
	if(! user_id ){
		messages.push("user id is mandatory");
	}

	if (! author ||  author.length<4 || author.length>50) {
		messages.push("author is mandatory and must be>=rs.0");
	}
	if(! no_of_books){
		messages.push("user id is mandatory");
	}
	
	
	

	if (messages.length > 0) {
		// display the errors
		var errors = $("<ul>").addClass("alert alert-danger");
		$("#errors1").html(errors);
		messages.forEach(function(msg) {
			errors.append("<li>" + msg + "<li>");

		});

		return false;

	}
	return true;

}





