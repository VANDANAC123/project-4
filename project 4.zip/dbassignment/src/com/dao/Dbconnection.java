package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.slk.training.Input;

public class Dbconnection {  
	private Connection openConnection() throws ClassNotFoundException, SQLException  {
		Class.forName("org.h2.Driver");
		String url = "jdbc:h2:tcp://localhost/~/slk_training_2018_12";
		String user = "sa";
		String password = "";
		return DriverManager.getConnection(url, user, password);
	}
	
	 public void AddNewUser1(Input r) {
			
		 String sql="insert into user values(?,?)";
		 try(Connection conn =openConnection();
					PreparedStatement stmt=conn.prepareStatement(sql);
					)
		 {
			 
				stmt.setString(1,r.getUsername());
				stmt.setString(2, r.getPassword());
				
				stmt.executeUpdate();
				
			
		 }catch (Exception ex) {
				
				ex.printStackTrace();
				
			}
		 }
	      
	 public List<Input> getuserdetails()
	      {
	    	  List<Input> list=new ArrayList<>();
	  		String sql="select * from user";
	  		
	  		try(Connection conn =openConnection();
	  				PreparedStatement stmt=conn.prepareStatement(sql);
	  				ResultSet rs=stmt.executeQuery();)
	  		{
	  			while(rs.next())
	  			{
	  				Input u=new Input();
	  				u.setUsername(rs.getString("username"));
	  				u.setPassword(rs.getString("password"));
	  				
	  				list.add(u);
	  				
	  			}
	  			
	  		}
	  		catch (Exception ex) {
	  			ex.printStackTrace();
	  		}
	  		return list;
	  	}

		
}
