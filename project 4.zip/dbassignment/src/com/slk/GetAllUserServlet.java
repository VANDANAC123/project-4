package com.slk;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Dbconnection;
import com.slk.training.Input;

//import com.slk.training.ManagerDetails;


@WebServlet("/GetAllUserServlet")
public class GetAllUserServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Dbconnection pm = new Dbconnection();
		List<Input> list = pm. getuserdetails();

		request.setAttribute("Input", list);
		RequestDispatcher rd =  request.getRequestDispatcher("/WEB-INF/show.jsp");
		rd.forward(request, response);

		
	}
}

	
	
