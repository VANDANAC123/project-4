package com.slk;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Dbconnection;
import com.slk.training.Input;
//import com.slk.training.ManagerDetails;
//import com.slk.training.user;

@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {


	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//PrintWriter out = response.getWriter();
		String input;
		// int input1;
		Input u = new Input();

		input = request.getParameter("username");
		u.setUsername(input);
		input = request.getParameter("password");
		// System.out.println(input);
		u.setPassword(input);
		
		Dbconnection md = new Dbconnection();
		md.AddNewUser1(u);

		response.sendRedirect("./GetAllUserServlet");
	}

}

